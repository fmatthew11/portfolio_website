/*!
=========================================================
* Meyawo Landing page
=========================================================

* Copyright: 2019 DevCRUD (https://devcrud.com)
* Licensed: (https://devcrud.com/licenses)
* Coded by www.devcrud.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// smooth scroll
$(document).ready(function(){
    $(".navbar .nav-link").on('click', function(event) {

        if (this.hash !== "") {

            event.preventDefault();

            var hash = this.hash;

            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 700, function(){
                window.location.hash = hash;
            });
        } 
    });
});

function scrollToSection(sectionId) {
    var section = document.getElementById(sectionId);
    section.scrollIntoView({ behavior: 'smooth' });
  }

// navbar toggle
$('#nav-toggle').click(function(){
    $(this).toggleClass('is-active')
    $('ul.nav').toggleClass('show');
});


document.addEventListener("DOMContentLoaded", function() {
    // Function to initialize likes for each blog post
    function initializeLikes(postId) {
        const likeBtn = document.querySelector(`[data-post-id="${postId}"]`);
        const likesCount = likeBtn.querySelector('.likes-count');

        // Get the current number of likes from localStorage
        let likes = localStorage.getItem(`likes-${postId}`) || 0;
        likesCount.textContent = likes;

        // Handle the click event for the like button
        likeBtn.addEventListener('click', function(e) {
            e.preventDefault();  // Prevent any default action
            likes = parseInt(likes) + 1;  // Increment likes count
            likesCount.textContent = likes;  // Update the display
            localStorage.setItem(`likes-${postId}`, likes);  // Store the updated count
        });
    }

    // Initialize likes for all blog posts
    document.querySelectorAll('.blog-card').forEach(post => {
        const postId = post.getAttribute('data-post-id');
        initializeLikes(postId);
    });
});
